# مباحث ویژه تمرین دوم  
# taha tehrani nasab      -        404217290
