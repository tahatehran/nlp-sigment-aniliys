# train_models.py – Train multiple classifiers on 20 Newsgroups dataset
# taha tehrani nasab      -        404217290
import re
import numpy as np
import pandas as pd
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier

def clean_text(text, stop_words):
    text = str(text).lower()
    text = re.sub(r'\W+', ' ', text)
    words = text.split()
    words = [word for word in words if word not in stop_words]
    return ' '.join(words)

# 1. Load data
newsgroups = fetch_20newsgroups(subset='all', remove=('headers', 'footers', 'quotes'))
texts, labels = newsgroups.data, newsgroups.target

# 2. Preprocess text (clean + TF-IDF)
stop_words = set(stopwords.words('english'))
cleaned_texts = [clean_text(t, stop_words) for t in texts]

vectorizer = TfidfVectorizer(max_features=2000)
X = vectorizer.fit_transform(cleaned_texts)

# 3. Split into train & test
X_train, X_test, y_train, y_test = train_test_split(X, labels, test_size=0.2, random_state=42)

# 4. Define models
models = [
    ('Logistic Regression', LogisticRegression(max_iter=200)),
    ('Naive Bayes', MultinomialNB()),
    ('SVM Linear', SVC(kernel='linear')),
    ('Random Forest', RandomForestClassifier(n_estimators=100)),
    ('XGBoost', XGBClassifier(use_label_encoder=False, eval_metric='mlogloss')),
    ('Decision Tree', DecisionTreeClassifier()),
    ('KNN', KNeighborsClassifier()),
    ('Gradient Boosting', GradientBoostingClassifier()),
    ('AdaBoost', AdaBoostClassifier()),
    ('Extra Trees', RandomForestClassifier(n_estimators=100, bootstrap=True, max_features='sqrt'))
]

# 5. Train and evaluate
results = []
for name, model in models:
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    results.append((name, acc))
    print(f"{name}: Accuracy = {acc:.4f}")

# 6. Print sorted results
df_results = pd.DataFrame(results, columns=['Model', 'Accuracy'])
print("\n=== Results sorted by accuracy ===")
print(df_results.sort_values(by='Accuracy', ascending=False))
