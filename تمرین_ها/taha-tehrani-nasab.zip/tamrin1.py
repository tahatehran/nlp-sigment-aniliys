import requests
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Download necessary NLTK data (only needed once)
nltk.download('punkt', quiet=True)
nltk.download('punkt_tab', quiet=True)
nltk.download('stopwords', quiet=True)

# List of URLs to process sequentially
urls = [
    "https://cdn.powix.ir/bot/69ef3651d58ec.txt",
    "https://cdn.powix.ir/bot/69ef365959c5d.txt"
]

# Load English stopwords
stop_words = set(stopwords.words('english'))

# Process files one by one
for index, url in enumerate(urls, 1):
    print(f"\n{'=' * 50}")
    print(f"Processing File #{index}: {url}")
    print(f"{'=' * 50}")

    try:
        # 1. Download the file
        response = requests.get(url)
        response.raise_for_status()  # Raise an error for bad status codes

        # 2. Read the text content
        raw_text = response.text

        # 3. Tokenize the text (split into words)
        tokens = word_tokenize(raw_text)

        # Count initial tokens
        initial_count = len(tokens)
        print(f"Initial token count: {initial_count}")

        # 4. Filter out stopwords and non-alphabetic characters
        # Keep only words that are alphabetic and not in the stop words list
        filtered_tokens = [
            word.lower() for word in tokens
            if word.isalpha() and word.lower() not in stop_words
        ]

        # Count tokens after filtering
        final_count = len(filtered_tokens)
        print(f"Token count after removing stopwords: {final_count}")

        # Show a sample of the remaining words
        print(f"Sample of remaining words: {filtered_tokens[:10]}")

    except requests.exceptions.RequestException as e:
        print(f"Error downloading file #{index}: {e}")
    except Exception as e:
        print(f"Error processing file #{index}: {e}")

print("\n" + "=" * 50)
print("All files processed successfully.")
print("=" * 50)