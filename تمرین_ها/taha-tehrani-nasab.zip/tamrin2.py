# --- 1. Install and Import Libraries ---
# Run this cell once to install dependencies
import subprocess
import sys


def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])


# Install NLTK and spaCy
install("nltk")
install("spacy")

# Import libraries
import requests
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import spacy

# --- 2. Download Data ---
# Download NLTK data
print("Downloading NLTK data...")
nltk.download('punkt', quiet=True)
nltk.download('punkt_tab', quiet=True)
nltk.download('stopwords', quiet=True)

# Download and load spaCy model
print("Downloading spaCy model...")
subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
nlp = spacy.load("en_core_web_sm")

# --- 3. Define Configuration ---
# List of URLs to process sequentially
urls = [
    "https://cdn.powix.ir/bot/69ef3651d58ec.txt",
    "https://cdn.powix.ir/bot/69ef365959c5d.txt"
]

# Load stopwords for both libraries
nltk_stop_words = set(stopwords.words('english'))
spacy_stop_words = spacy.lang.en.stop_words.STOP_WORDS

# --- 4. Processing Loop ---
for index, url in enumerate(urls, 1):
    print(f"\n{'=' * 60}")
    print(f"Processing File #{index}: {url}")
    print(f"{'=' * 60}")

    try:
        # Step A: Download the file
        response = requests.get(url)
        response.raise_for_status()
        raw_text = response.text

        # Check if text is empty
        if not raw_text.strip():
            print("Warning: File is empty or could not be read.")
            continue

        # ==========================================
        # PART 1: NLTK Processing
        # ==========================================
        print("\n--- NLTK Processing ---")

        # Tokenize using NLTK
        nltk_tokens = word_tokenize(raw_text)
        initial_nltk_count = len(nltk_tokens)

        # Filter: Keep only alphabetic words that are not stopwords
        nltk_filtered = [
            word.lower() for word in nltk_tokens
            if word.isalpha() and word.lower() not in nltk_stop_words
        ]

        final_nltk_count = len(nltk_filtered)
        removed_nltk = initial_nltk_count - final_nltk_count

        print(f"Initial Tokens (NLTK): {initial_nltk_count}")
        print(f"Filtered Tokens (NLTK): {final_nltk_count}")
        print(f"Removed Words (NLTK): {removed_nltk}")
        print(f"Sample NLTK Output: {nltk_filtered[:10]}")

        # ==========================================
        # PART 2: spaCy Processing
        # ==========================================
        print("\n--- spaCy Processing ---")

        # Process with spaCy
        doc = nlp(raw_text)

        # Filter: Keep only words that are alpha, not punctuation, and not stopwords
        spacy_filtered = [
            token.text.lower() for token in doc
            if token.is_alpha and not token.is_punct and token.text.lower() not in spacy_stop_words
        ]

        final_spacy_count = len(spacy_filtered)
        removed_spacy = len(list(doc)) - final_spacy_count  # Approximate removal

        print(f"Initial Tokens (spaCy): {len(list(doc))}")
        print(f"Filtered Tokens (spaCy): {final_spacy_count}")
        print(f"Removed Words (spaCy): {removed_spacy}")
        print(f"Sample spaCy Output: {spacy_filtered[:10]}")

    except requests.exceptions.RequestException as e:
        print(f"Error downloading file #{index}: {e}")
    except Exception as e:
        print(f"Error processing file #{index}: {e}")

print("\n" + "=" * 60)
print("All files processed successfully using both NLTK and spaCy.")
print("=" * 60)